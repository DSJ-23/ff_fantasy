
const helper_functions = require('./helper_functions');

console.log(helper_functions.apiresponse(200, "but she fell in love with an english man"))


// https://w9gy04gtw4.execute-api.us-east-1.amazonaws.com/dev/posts

// {
//     "title": "helo"
// }